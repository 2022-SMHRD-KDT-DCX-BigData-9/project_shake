package com.smhrd.shake.entity;

import lombok.Data;

@Data
public class CocktailInfo {
	private int cock_idx;
	private String cock_name;
	private String cock_ingredient;
	private String cock_desc;
}
