package com.smhrd.shake.entity;

import lombok.Data;

@Data
public class CockIngredient {
	private int cock_idx;
	private String cock_name;
	private String ingredient1;
	private String ingredient2;
	private String ingredient3;
	private String ingredient4;
	private String ingredient5;
	private String ingredient6;
	private String ingredient7;
	private String ingredient8;
	private String ingredient9;
	private String ingredient10;
}
