package com.smhrd.shake.entity;

import lombok.Data;

@Data
public class CockMix {
	private int cock_mix_idx;
	private String drink;
	private String liqueur;
	private String beverage;
	private String fruit;
	private String etc; 
}
