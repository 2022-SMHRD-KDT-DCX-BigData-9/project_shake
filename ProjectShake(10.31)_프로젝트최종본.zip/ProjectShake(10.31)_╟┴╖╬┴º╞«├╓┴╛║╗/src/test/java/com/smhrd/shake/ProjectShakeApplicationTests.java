package com.smhrd.shake;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectShakeApplicationTests {

	@Test
	void contextLoads() {
	}

}
